﻿namespace Lab_13
{
    partial class fPlanet
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.tbDistanceFromSun = new System.Windows.Forms.TextBox();
            this.tbDiameter = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.tbSatellites = new System.Windows.Forms.TextBox();
            this.tbOrbitalPeriod = new System.Windows.Forms.TextBox();
            this.tbMass = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.chbHasLife = new System.Windows.Forms.CheckBox();
            this.chbHasRings = new System.Windows.Forms.CheckBox();
            this.btnOk = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(29, 54);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Назва планети";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(29, 114);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(72, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Діаметр (км)";
            this.label2.Click += new System.EventHandler(this.label2_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(29, 168);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Дистанція до сонця (млн км)";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(29, 221);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(144, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Масса (кг)(пишіть через \'e\')";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(29, 276);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(132, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Орбітальни період (роки)";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.tbDistanceFromSun);
            this.groupBox1.Controls.Add(this.tbDiameter);
            this.groupBox1.Controls.Add(this.tbName);
            this.groupBox1.Controls.Add(this.tbSatellites);
            this.groupBox1.Controls.Add(this.tbOrbitalPeriod);
            this.groupBox1.Controls.Add(this.tbMass);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(353, 382);
            this.groupBox1.TabIndex = 5;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Загальні дані";
            // 
            // tbDistanceFromSun
            // 
            this.tbDistanceFromSun.Location = new System.Drawing.Point(202, 165);
            this.tbDistanceFromSun.Name = "tbDistanceFromSun";
            this.tbDistanceFromSun.Size = new System.Drawing.Size(117, 20);
            this.tbDistanceFromSun.TabIndex = 11;
            // 
            // tbDiameter
            // 
            this.tbDiameter.Location = new System.Drawing.Point(202, 111);
            this.tbDiameter.Name = "tbDiameter";
            this.tbDiameter.Size = new System.Drawing.Size(117, 20);
            this.tbDiameter.TabIndex = 10;
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(202, 51);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(117, 20);
            this.tbName.TabIndex = 9;
            // 
            // tbSatellites
            // 
            this.tbSatellites.Location = new System.Drawing.Point(202, 334);
            this.tbSatellites.Name = "tbSatellites";
            this.tbSatellites.Size = new System.Drawing.Size(117, 20);
            this.tbSatellites.TabIndex = 8;
            // 
            // tbOrbitalPeriod
            // 
            this.tbOrbitalPeriod.Location = new System.Drawing.Point(202, 273);
            this.tbOrbitalPeriod.Name = "tbOrbitalPeriod";
            this.tbOrbitalPeriod.Size = new System.Drawing.Size(117, 20);
            this.tbOrbitalPeriod.TabIndex = 7;
            // 
            // tbMass
            // 
            this.tbMass.Location = new System.Drawing.Point(202, 218);
            this.tbMass.Name = "tbMass";
            this.tbMass.Size = new System.Drawing.Size(117, 20);
            this.tbMass.TabIndex = 6;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(29, 337);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(109, 13);
            this.label6.TabIndex = 5;
            this.label6.Text = "Кількість супутників";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.chbHasLife);
            this.groupBox2.Controls.Add(this.chbHasRings);
            this.groupBox2.Location = new System.Drawing.Point(12, 400);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(353, 111);
            this.groupBox2.TabIndex = 6;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Додаткові дані";
            // 
            // chbHasLife
            // 
            this.chbHasLife.AutoSize = true;
            this.chbHasLife.Location = new System.Drawing.Point(17, 68);
            this.chbHasLife.Name = "chbHasLife";
            this.chbHasLife.Size = new System.Drawing.Size(121, 17);
            this.chbHasLife.TabIndex = 1;
            this.chbHasLife.Text = "Є життя на планеті";
            this.chbHasLife.UseVisualStyleBackColor = true;
            // 
            // chbHasRings
            // 
            this.chbHasRings.AutoSize = true;
            this.chbHasRings.Location = new System.Drawing.Point(17, 34);
            this.chbHasRings.Name = "chbHasRings";
            this.chbHasRings.Size = new System.Drawing.Size(127, 17);
            this.chbHasRings.TabIndex = 0;
            this.chbHasRings.Text = "Планета має кільця";
            this.chbHasRings.UseVisualStyleBackColor = true;
            // 
            // btnOk
            // 
            this.btnOk.Location = new System.Drawing.Point(404, 56);
            this.btnOk.Name = "btnOk";
            this.btnOk.Size = new System.Drawing.Size(75, 23);
            this.btnOk.TabIndex = 2;
            this.btnOk.Text = "Ok";
            this.btnOk.UseVisualStyleBackColor = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(404, 85);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Скасувати";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.button2_Click);
            // 
            // fPlanet
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Cornsilk;
            this.ClientSize = new System.Drawing.Size(504, 533);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btnOk);
            this.Controls.Add(this.groupBox1);
            this.MaximizeBox = false;
            this.Name = "fPlanet";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Дані про нову планету";
            this.Load += new System.EventHandler(this.fPlanet_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.CheckBox chbHasLife;
        private System.Windows.Forms.CheckBox chbHasRings;
        private System.Windows.Forms.Button btnOk;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.TextBox tbDistanceFromSun;
        private System.Windows.Forms.TextBox tbDiameter;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.TextBox tbSatellites;
        private System.Windows.Forms.TextBox tbOrbitalPeriod;
        private System.Windows.Forms.TextBox tbMass;
    }
}